#!/usr/bin/env bash
# One-step publish: creates the GitHub repo under somyagargops and deploys to Vercel.
# Needs: git, GitHub CLI (gh) logged in as somyagargops, and Node.js (for npx vercel).
set -e
REPO="onecolor-website"
git init -b main 2>/dev/null || true
git add .
git commit -m "OneColor website: home, shop, product page, shade finder" || true
gh repo create "somyagargops/$REPO" --public --source=. --remote=origin --push
npx vercel@latest --prod
